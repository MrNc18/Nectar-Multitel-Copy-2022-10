import React from 'react'

function ServiceBanner() {
  return (
    <div>
      fghjk
    </div>
  )
}

export default ServiceBanner
