import React from 'react'

function Mobile() {
  return (
    <div>Mobile</div>
  )
}

export default Mobile