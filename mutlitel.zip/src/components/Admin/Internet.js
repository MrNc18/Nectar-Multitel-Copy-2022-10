import React from 'react'

function Internet() {
  return (
    <div>Internet</div>
  )
}

export default Internet