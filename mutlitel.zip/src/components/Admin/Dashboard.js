import React from 'react'

function Dashboard() {
  return (
    <div id="layoutSidenavContent">
      <div className="container-fluid">
        <h3 className="mt-4 mb-4">Dashboard</h3>
        </div>
        </div>
  )
}

export default Dashboard