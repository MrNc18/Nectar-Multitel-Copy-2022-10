import React from 'react'

function Router() {
  return (
    <div>Router</div>
  )
}

export default Router