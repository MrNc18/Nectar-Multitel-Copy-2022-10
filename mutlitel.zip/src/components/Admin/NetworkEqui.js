import React from 'react'

function NetworkEqui() {
  return (
    <div>NetworkEqui</div>
  )
}

export default NetworkEqui