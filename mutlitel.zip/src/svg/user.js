export const user = (
  <svg xmlns="http://www.w3.org/2000/svg" width="14.333" height="16" viewBox="0 0 14.333 16">
    <g id="User" transform="translate(-5.5 -4)">
      <path id="Path_126" data-name="Path 126" d="M19.333,27.5V25.833A3.333,3.333,0,0,0,16,22.5H9.333A3.333,3.333,0,0,0,6,25.833V27.5" transform="translate(0 -8)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
      <path id="Path_127" data-name="Path 127" d="M18.667,7.833A3.333,3.333,0,1,1,15.333,4.5,3.333,3.333,0,0,1,18.667,7.833Z" transform="translate(-2.667)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
    </g>
  </svg>
)

