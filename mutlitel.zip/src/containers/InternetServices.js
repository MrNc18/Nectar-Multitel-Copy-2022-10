import React from 'react'
import ServiceBanner from '../components/atoms/ServiceBanner'

function InternetServices() {
  return (
    <>
      <ServiceBanner />
    </>
  )
}

export default InternetServices
